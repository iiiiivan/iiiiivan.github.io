using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerController : MonoBehaviour
{
    public TextMeshProUGUI testText;
    public Animator animator;
    public SkinnedMeshRenderer smr1;
    public SkinnedMeshRenderer smr2;
 

    Rigidbody rb;
    float speed = 5f;
    float time = 0f;
    int lane = 0;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
    void Update()
    {
        animator.SetFloat("Blend", speed / 20 + 0.7f);


        speed += 0.01f;
        time -= Time.deltaTime;

        testText.text = time.ToString();


        rb.velocity = transform.forward * speed;
        
        

        if (Input.GetKeyDown("a") && lane > -2)
        {
            rb.MovePosition(transform.position - transform.right);
            lane -= 1;
        }

        if (Input.GetKeyDown("d") && lane < 2)
        {
            rb.MovePosition(transform.position + transform.right);
            lane += 1;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "obstacle" && time <= 0)
        {
            speed *= 0.5f;
            StartCoroutine(Blink());
        }
        if (other.tag == "power")
        {
            time = 2;
            
        }
        if (other.tag == "corner")
        {
            transform.localEulerAngles = new Vector3(0, 90, 0);
            transform.position = new Vector3(other.transform.position.x, gameObject.transform.position.y, other.transform.position.z);
            lane = 0;
        }
        
    }

    IEnumerator Blink()
    {
        smr1.enabled = false;
       
        yield return new WaitForSeconds(0.08f);
        smr1.enabled = true;
       
        yield return new WaitForSeconds(0.08f);
        smr1.enabled = false;

        yield return new WaitForSeconds(0.08f);
        smr1.enabled = true;

        yield return new WaitForSeconds(0.08f);
        smr1.enabled = false;

        yield return new WaitForSeconds(0.08f);
        smr1.enabled = true;

        yield return new WaitForSeconds(0.08f);
        smr1.enabled = false;

        yield return new WaitForSeconds(0.08f);
        smr1.enabled = true;

        yield return new WaitForSeconds(0.08f);
    }

}
