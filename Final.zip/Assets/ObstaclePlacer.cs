using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class ObstaclePlacer : MonoBehaviour
{
    public GameObject trackPrefab;
    public GameObject track2Prefab;
    public GameObject rwallPrefab;
    public GameObject lwallPrefab;
    public GameObject tallPrefab;
    public GameObject shortPrefab;
    public GameObject powerPrefab;
    public GameObject cornerPrefab;


    void Start()
    {
        

        Instantiate(cornerPrefab, new Vector3(0, 0.5f, 502.5f), Quaternion.identity);
        Instantiate(trackPrefab, new Vector3(2.5f, 0, 500), Quaternion.identity);
        Instantiate(lwallPrefab, new Vector3(-2.5f, 0, 505.8f), Quaternion.Euler(0, 180, 0));
        Instantiate(lwallPrefab, new Vector3(-3.3f, 0, 500), Quaternion.Euler(0, 90, 0));

//Track1
        for (int z = -5; z <= 495; z += 5)
        {
            Instantiate(trackPrefab, new Vector3(2.5f, 0, z), Quaternion.identity);
            Instantiate(rwallPrefab, new Vector3(3.3f, 0, z+5), Quaternion.Euler(0, -90, 0));
            Instantiate(lwallPrefab, new Vector3(-3.3f, 0, z), Quaternion.Euler(0, 90, 0));
        }

        for (int z = 5; z <= 495; z += 7)
        {
            var dice = Random.Range(0, 9);
            if (dice == 0)
            {
                Instantiate(tallPrefab, new Vector3(-1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 2, z), Quaternion.identity);
                Instantiate(tallPrefab, new Vector3(1, 0, z), Quaternion.identity);
                Instantiate(powerPrefab, new Vector3(0, 0, z), Quaternion.identity);
            }
            if (dice == 1)
            {
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(2, 0, z), Quaternion.identity);

            }
            if (dice == 2)
            {
                Instantiate(shortPrefab, new Vector3(-2, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(-1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);

            }
            if (dice == 3)
            {
                Instantiate(shortPrefab, new Vector3(1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(-1, 0, z), Quaternion.identity);
            }
            if (dice == 4)
            {
                Instantiate(shortPrefab, new Vector3(-2, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(-1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(2, 0, z), Quaternion.identity);
            }
            if (dice == 5)
            {
                Instantiate(shortPrefab, new Vector3(-2, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(2, 0, z), Quaternion.identity);
            }
            if (dice == 6)
            {
                Instantiate(shortPrefab, new Vector3(-2, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(2, 0, z), Quaternion.identity);
            }
            if (dice == 7)
            {
                Instantiate(shortPrefab, new Vector3(-2, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(-1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(2, 0, z), Quaternion.identity);
            }
            if (dice == 8)
            {
                Instantiate(shortPrefab, new Vector3(-2, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(-1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(1, 0, z), Quaternion.identity);
            }
            if (dice == 9)
            {
                Instantiate(shortPrefab, new Vector3(-1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(0, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(1, 0, z), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(2, 0, z), Quaternion.identity);
            }
        }

//Track2
        for (int x = 0; x <= 500; x += 5)
        {
            Instantiate(track2Prefab, new Vector3(x+2.5f, 0, 500), Quaternion.Euler(0, 90, 0));
            Instantiate(lwallPrefab, new Vector3(x+2.5f, 0, 505.8f), Quaternion.Euler(0, 180, 0));
            Instantiate(rwallPrefab, new Vector3(x+7.5f, 0, 499.2f), Quaternion.Euler(0, 0, 0));
        }

        for (int x = 5; x <= 495; x += 7)
        {
            var dice = Random.Range(0, 9);
            if (dice == 0)
            {
                Instantiate(tallPrefab, new Vector3(x+2.5f, 0, 501.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 2, 502.5f), Quaternion.identity);
                Instantiate(tallPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity);
                Instantiate(powerPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity);
            }
            if (dice == 1)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 500.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 501.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity);               
            }
            if (dice == 2)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 504.5f), Quaternion.identity);               
            }
            if (dice == 3)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 500.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity); 
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 504.5f), Quaternion.identity);               
            }
            if (dice == 4)
            {
                Instantiate(shortPrefab, new Vector3(x + 2.5f, 0, 500.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x + 2.5f, 0, 501.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x + 2.5f, 0, 502.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x + 2.5f, 0, 504.5f), Quaternion.identity);
            }
            if (dice == 5)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 500.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 501.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity); 
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity);               
            }
            if (dice == 6)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 501.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity); 
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 504.5f), Quaternion.identity);
            }if (dice == 7)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 500.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 501.5f), Quaternion.identity); 
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 504.5f), Quaternion.identity);
            }
            if (dice == 8)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 500.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 504.5f), Quaternion.identity);           
            }
            if (dice == 9)
            {
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 501.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 502.5f), Quaternion.identity);
                Instantiate(shortPrefab, new Vector3(x+2.5f, 0, 503.5f), Quaternion.identity);           
            }
            
        }

    }

    void Update()
    {
        
    }
}
